/***************************************************************
*  Copyright notice
*
*  (c) 2012 - 2014 Gisele Wendl <gisele.wendl@toctoc.ch>
*  toctoc_comments javascript file handlich bindings of events, located in the footer of the HTML document
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/*
 * Init of working variables
 */

var tccid = '';
var tccid2 = '';
var tccid3 = '';
var tcnum = 0;
var caseupl=0;
var savemove = [];
var lastemojicid='';

if (!savemove['nrml-']) {
	savemove['nrml-'] = [];
	savemove['top-'] = [];
}
/*
 * emoji events
 */

function resetemojiopenericonandpanel(prevemojicid) {
	(function($) {
		if (!$('#tx-tc-smilie-popup-' + prevemojicid).hasClass("tx-tc-nodisp")) {
			$('#tx-tc-smilie-popup-' + prevemojicid).addClass("tx-tc-nodisp");
			$('#tx-tc-smilie-popup-' + prevemojicid).removeClass("tx-tc-blockdisp");
		}
		if ($('#tx-tc-smilie-icon-' + prevemojicid).hasClass("open")) {
			$('#tx-tc-smilie-icon-' + prevemojicid).removeClass("open");
			if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
				$('#tx-tc-smilie-icon-' + prevemojicid).attr("title",utf8_decode(tcb64_dec(textAddemoji)));
			}
		} else {
			$('.tx-tc-tooltip').hide();
		}
		if ($('#tx-tc-smilie-popup-' + prevemojicid).html!='') {
			$('.tx-tc-tooltipemoji').hide();
			$('#tx-tc-smilie-popup-' + prevemojicid).html('');
		}
		return '';
	})(jQuery);
}

function selectemoji(cid, prevemojicid) {
	if (prevemojicid === cid) {
		return resetemojiopenericonandpanel(prevemojicid);
	}
	if (prevemojicid !== '') {
		prevemojicid = resetemojiopenericonandpanel(prevemojicid);
	}

	if (!jQuery('#tx-tc-smilie-popup-' + cid).hasClass("tx-tc-blockdisp")) {
		jQuery('#tx-tc-smilie-popup-' + cid).removeClass("tx-tc-nodisp");
		jQuery('#tx-tc-smilie-popup-' + cid).addClass("tx-tc-blockdisp");
		jQuery('#tx-tc-smilie-popup-' + cid).html(tcsmiliecardhtml);
		jQuery('#tx-tc-smilie-icon-' + cid).addClass("open");
		if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
			jQuery('#tx-tc-smilie-icon-' + cid).attr("title",utf8_decode(tcb64_dec(textCloseemoji)));
		}
	}
	return cid;
}

function tcrebindemo(topid) {
	(function($) {
		// emojis
		// smilie selector
		if (!topid) {
			topid = '';
		} else {
			if (topid !== '') {
				topid = topid + ' ';
			}
		}
		$(topid + '.tx-tc-smilie-icon').on("mouseenter", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-smilie-icon-','');
			if ((this.id).length !== tccid.length) {
				tttip('t101','#tx-tc-smilie-icon-' + tccid + '[title]');
			}
		});
		$(topid + '.tx-tc-smilie-icon').on("mouseout", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-smilie-icon-','');
			if ((this.id).length !== tccid.length) {
				tttip('t101','#tx-tc-smilie-icon-' + tccid + '[title]');
			}
		});


		$(topid + '.tx-tc-smilie-icon').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-smilie-icon-','');
			if ((this.id).length !== tccid.length) {
				tttip('hide');
				$('.tx-tc-tooltipemoji').hide();
				$('.tx-tc-tooltip').remove();
				$(this).removeData('tooltip');
				lastemojicid= selectemoji(tccid, lastemojicid);

				if (lastemojicid!='') {
					$('.tx-tc-emo-int-img').on("click", function() {
						tccid = this.id;
						tccid = tccid.replace('tx-tc-emo-int-img-','');
						tccid = tccid.replace('\\\'','\'');
						if ((this.id).length !== tccid.length) {
							insertemoji(tccid);
						}

					});
					$('.tx-tc-emoselpage').on("click", function() {
						tccid = this.id.replace('tx-tc-emoselpage-','');
						if ((this.id).length !== tccid.length) {
							tcidarr = String(tccid).split("__");
							if (tcidarr.length > 1) {
								emoselpage(tcidarr[0], tcidarr[1]);
							}
						}
					});
					$('.tx-tc-smilie-popup').on( "mouseenter", function() {
						tccid = this.id;
						tccid = tccid.replace('tx-tc-smilie-popup-','');
						if ((this.id).length !== tccid.length) {
							if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
								$('#tx-tc-smilie-popup-' + tccid +' .tx-tc-emo-bot-nav span[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
								$('#tx-tc-smilie-popup-' + tccid +' .moji[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
								$('#tx-tc-smilie-popup-' + tccid +' img[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
							} else {
								$('#tx-tc-smilie-popup-' + tccid +' .tx-tc-emo-bot-nav span').removeAttr('title');
								$('#tx-tc-smilie-popup-' + tccid +' .moji').removeAttr('title');
								$('#tx-tc-smilie-popup-' + tccid +' img').removeAttr('title');
							}								
							
						}

					});
				}
			}
		});

		if (confuseEmoji>0) {
			if (topid !== '') {
				if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
					$(topid + '.tx-tc-smilie-icon[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip'});
				} else {
					$(topid + '.tx-tc-smilie-icon').removeAttr('title');
 
				}
			} else {
				if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
					$('.tx-tc-smilie-icon[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip'});
				} else {
					$('.tx-tc-smilie-icon').removeAttr('title');
				}
			}
		}
		})(jQuery);
}

/*
 * function handling keyup, click and paste in comments form textarea
 */

function checkpaste(tObjId, ekeyCode, epageX, epageY, ewhich) {
	tccid = tObjId;

	tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
	if ((tObjId).length !== tccid.length) {
		tccid2 =tccid;
		tcidarr = String(tccid).split("6g9");

		if (tcidarr.length === 3) {
			tccid=tcidarr[0];
		} else {
			tccid=tccid2;
		}
		if (tccid2 == 1) {
			activelang = 'jedi';
		}
		tcnum = toctoc_checkurl(ekeyCode,document.getElementById(tctnme + tccid2),tccid2, previewstarted[tccid2], activelang, confpvsheight, commentsAjaxData[tccid],  commentsAjaxDataAtt[tccid], maxCommentLength, epageX, epageY, ewhich);
        previewstarted[tccid2] = tcnum;
	}
}

/*
 * main rebind function, called on document level in page loads
 * then called using topid for identification of areas where redinds should apply
 */
function tcrebind(topid){
	(function($) {
		if (topid == 'undefined') {
			topid='';
		}
		if (!topid) {
			topid = '';
		} else {
			if (topid !== '') {
				topid = topid + ' ';
			}
		}
		var trgrebind = '';
		if (topid.replace('tx-tc-cts-ctsbrowse-','') != topid) {
			trgrebind = 'browse';
		} else if (topid.replace('tx-tc-cts-ct-tx-tc-cts_','') != topid) {
			trgrebind = 'comment';
		}

		// functions //

		// the autogrow function used for the commenting area
		$.fn.autoGrow = function(){
			return this.each(function(){
				var heightDefault = this.offsetHeight;
				var grow = function() {
					if (this.offsetHeight !== heightDefault) {
						deltah =parseInt(this.offsetHeight)-parseInt(heightDefault);
						nodename = this.parentNode.id;
						formhiderdivid='formhider-' + nodename.substr(9,100);
						newmargin='0';
						document.getElementById(formhiderdivid).style.margin = newmargin;
						heightDefault=this.offsetHeight;
						pushmain(deltah,1);

					}
				};
			});
		};

		function init_triggers_by_clicks (itopid) {
			// give a "little water" to the commenting forms, so the grow and shrink automatically
			if (trgrebind != 'browse') {
				if (trgrebind != 'comment') {
					$(itopid + '.tx-tc-commentsAjaxData').trigger("click");
					$(itopid + '.tx-tc-sharre-trigger').trigger("click");
				}
				$(itopid + '.tx-tc-ctinput-textarea').autoGrow();
				//form error handler
				$(itopid + '.tx-tc-frmerrhndl').trigger("click");
				// get the cookie data and put it in forms input fields
				$(itopid + '.tx-tc-setuserdata').trigger("click");
				//setup watermarks in mainform
				$(itopid + '.tx-tc-wtrmrk-formf').trigger("click");
				//setup triggers for uploading
				$(itopid + '.tx-tc-uplpic-trigger').trigger("click");
				//setup watermarks in comments			
				$(itopid + '.tx-tc-wtrmrk-tcnt').trigger("click");			
				// overlay mask jquery.tools popups
				$(itopid + "img[rel]").superpose({mask: {
			        color: '#5475C8',
			        loadSpeed: 200,
			        opacity: 0.2
			      }});
				// text "others like this ..."
				$(itopid + '.tx-tc-othertitle').trigger("click");
				if (trgrebind != 'comment') {	
					// trigger comments counting
					$(itopid + '.tx-tc-cmtvcntr').trigger("click");
				}
				// build sort_array
				$(itopid + '.tx-tc-sortinfo').trigger("click");			

			}
		}

		// captcha change in comments form
		function change_captcha(cid,ctype,ajaxdataconf) {
			document.getElementById('toctoc_comments_cap_'+cid).src="index.php?eID=toctoc_comments_ajax&cmd=getcap&captchatype="+ctype+"&cid="+cid+"&rnd=" + Math.random() + ajaxdataconf;
		}

		// tooltipp inits
		function tcinit_tooltipps() {
			tttip('t101', '.tx-tc-ct-pvs-images img[title]');
			if (trgrebind != 'comment') {
				tttip('t101', '.tx-tc-recent-cts-article img[title]');
				tttip('t101', '.tx-tc-atrts-ctlink a[title]');
				tttip('t101', '.tx-tc-rcentpic[title]');
				tttip('t201-5', '.tx-tc-trt-cts-article .tx-tc-rts-vote-bar div span[title]');
				tttip('t201-5', '.tx-tc-trt-cts-article .tx-tc-rts-vote-bar div a[title]');
				tttip('temo', '.tx-tc-box-trt-cts .tx-tc-trt-content span.emoji[title]');
				tttip('temo', '.tx-tc-box-trt-cts .tx-tc-trt-content img[title]');
				tttip('t101', '.tx-tc-trt-rating-rating img[title]');
				tttip('t101', '.tx-tc-trt-rating-img img[title]');
				tttip('t101', '.tx-tc-trt-rating-right img[title]');
				tttip('temo', '.tx-tc-recent-cts-article img[title]');
				tttip('temo', '.tx-tc-recent-cts-article .emoji[title]');
				if (locshowlesstooltips == 0) {
					tttip('t101', '.tx-tc-topmsgcls[title]');
				} else {
					$('.tx-tc-topmsgcls').removeAttr('title');
				}
				window.setTimeout("tttip('t101', '.tx-tc-shareicon[title]')",8000);
			}
			if (locshowlesstooltips == 0) {
				tttip('t101', '.tx-tc-dsclmrlistmenutitle[title]');
				tttip('t201-5', '.tx-tc-cookieclose[title]');
				tttip('t101', '.tx-tc-ct-actionforms span.tx-tc-ct-deletebutton[title]');
				tttip('t101', '.tx-tc-ct-actionforms span.tx-tc-ct-editbutton[title]');			
				tttip('t101', '.tx-tc-ct-div-ry-data[title]');
				tttip('t101', '.tx-tc-ct-form-field-ntf input[title]');
				tttip('t101', '.tx-tc-cookie-checker[title]');
				tttip('t101', '.tx-tc-cookieshow[title]');
				tttip('t101', '.tx-tc-terms-check[title]');			
				tttip('t201-5', '.tx-tc-cookieaccept[title]');
				tttip('t101', '.tx-tc-commentnricon[title]');
				tttip('t101', '.tx-tc-ct-denotifybutton[title]');
				tttip('t101', '.tx-tc-vidclose[title]');
				tttip('t101', '.tx-tc-pvs-vid-img_olay[title]');
				tttip('t101', '.tx-tc-cts-ctsbrowse-submit[title]');
				tttip('t101', '.tx-tc-cts-ctsbrowse-submit-hide[title]');
				tttip('t101', '.tx-tc-tcsroc[title]');	
				tttip('t101', '.tx-tc-ct-report img[title]');			
				tttip('t101', '.tx-tc-nbrofcomment-2 img[title]');	
			} else {
				$('.tx-tc-dsclmrlistmenutitle').removeAttr('title');
				$('.tx-tc-cookieclose').removeAttr('title');
				$('.tx-tc-ct-actionforms span.tx-tc-ct-deletebutton').removeAttr('title');
				$('.tx-tc-ct-actionforms span.tx-tc-ct-editbutton').removeAttr('title');			
				$('.tx-tc-ct-div-ry-data').removeAttr('title');
				$('.tx-tc-ct-form-field-ntf input').removeAttr('title');
				$('.tx-tc-cookie-checker').removeAttr('title');
				$('.tx-tc-cookieshow').removeAttr('title');
				$('.tx-tc-terms-check').removeAttr('title');			
				$('.tx-tc-cookieaccept').removeAttr('title');
				$('.tx-tc-commentnricon').removeAttr('title');
				$('.tx-tc-ct-denotifybutton').removeAttr('title');
				$('.tx-tc-vidclose').removeAttr('title');
				$('.tx-tc-pvs-vid-img_olay').removeAttr('title');
				$('.tx-tc-cts-ctsbrowse-submit').removeAttr('title');
				$('.tx-tc-cts-ctsbrowse-submit-hide').removeAttr('title');
				$('.tx-tc-tcsroc').removeAttr('title');	
				$('.tx-tc-ct-report img').removeAttr('title');			
				$('.tx-tc-nbrofcomment-2 img').removeAttr('title');	
			}			
			
			tttip('t101', '.tx-tc-userpic tx-tc-uimgsize[title]');
			tttip('t101', '.tx-tc-userpicf tx-tc-uimgsize[title]');
			tttip('t101', '.tx-tc-ct-box-ctpic img[title]');
			tttip('t101', '.tx-tc-othertitle[title]');
			tttip('t101', '.tx-tc-scopetitlebold[title]');
			tttip('t201-65', '.tx-tc-scopetitle[title]');
			tttip('t201-20', '.tx-tc-img-image a img[title]');
			tttip('t201-20', '.tx-tc-images-img-browse[title]');

		}

		// comments submit function
		function txtcctsubmitclick(tObj) {
			tccid = tObj.parentNode.parentNode.id.replace('cffs','');
			
			if ((tObj.parentNode.parentNode.id).length !== tccid.length) {
				tcidarr = String(tccid).split('__0');
				tccid3=tcidarr[0]; //CID
				tcidarr2 = String(tccid3).split('6g9');
				if (tcidarr2.length === 3) {
					tccid=tcidarr2[0];//Master CID
				} else {
					tccid=tccid3;
				}

				if (commentform_validate(tctnme + tccid3, tccid3)==true) {
					tccid2 = toctoc_comments_pi1_getUserData(tccid3);

					tcidarr2 = String(document.body.innerHTML).split(' tx-tc-reportcomment ');
					//tx-tc-reportcomment
					if ((parseInt(tccid3)  == 1) && (tcidarr2.length === 2)) {
						//report comment submit
						if (document.getElementById('tx_comments_pi1-cap1')) {
							if (document.getElementById('tx_comments_pi1-cap1').value != '') {
								document.getElementById('cf1').submit();
							}
						} else {
							document.getElementById('cf1').submit();
						}
					} else {
						commentsAjaxDataC[tccid]=tccid2;
						// : toctoc_comments_submit      (id,         rating,     ajaxData,                 check,    action,     cssident,    datac,                thisdata,	 capsess,    cid, caperr,            commentsImgs,        loggedon, extid,   webpagepreviewheight, windowpreviewhtml
						tcnum = toctoc_comments_submit(tcidarr[1], tcidarr[2], commentsAjaxData[tccid], tcidarr[3], tcidarr[4], tcidarr[5], tccid2, commentsAjaxThisData[tccid], tcidarr[6], tccid3, tcidarr[7], commentsAjaxDataImg[tccid], tcidarr[8], tcidarr[9], tcidarr[10], previewhtml[tccid]);
					}
				}
			}

		}

		// comments browse function
		function txtcbrowsesubmitclick(tObj,tccid) {
			if ((tObj.id).length !== tccid.length) {
				tcidarr = String(tccid).split("__0");
				if (tcidarr.length > 1) {
					tccid=tcidarr[0];
				}
				toctoc_comments_browse(tcidarr[1], tcidarr[2], commentsAjaxData[tccid], tcidarr[3], tcidarr[4], tcidarr[5], commentsAjaxDataC[tccid], commentsAjaxThisData[tccid], tcidarr[6], tccid, tcidarr[7], commentsAjaxDataImg[tccid]);
			}

		}

		// Eventlisteners //
		// Comment reply
		$(topid + '.tx-tc-ct-div-ry-data').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-ct-div-ry-','');

			if ((this.id).length !== tccid.length) {
				tcidarr = String(tccid).split("__0");
				// : commentreply(uid, previewselcommentcid, cid, ref, triggeredzone, triggereduid)
				if (tcidarr.length > 4) {
					tccid=tcidarr[1];
					tccid2=tcidarr[2];
					commentreply(tcidarr[0], previewselcomment[tccid], tccid , tccid2, tcidarr[3], tcidarr[4]);
				} else if (tcidarr.length > 1) {
					tccid=tcidarr[1];
					tccid2=tcidarr[2];
					commentreply(tcidarr[0], previewselcomment[tccid], tccid , tccid2);
				}

			}

		});

		// Preview comment
		$(topid + '.tx-tc-prvcnt-data').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-prvcnt-data-','');
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid2=tcidarr[0];
			} else {
				tccid2=tccid;
			}
			previewct(commentsAjaxData[tccid2],tccid,1);
		});
		$(topid + '.tx-tc-prvcnt-data-off').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-div-ct-prv-','');
			$(topid + '.tx-tc-tooltip').hide();
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid2=tcidarr[0];
			} else {
				tccid2=tccid;
			}
			previewct(commentsAjaxData[tccid2],tccid,0);
		});

		// setup tooltipps on ratings in the last moment
		$(topid + '.tx-tc-rts-cntrdata').on( "mouseenter", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-rts-container-scp-','');
			tcidarr = String(tccid).split("__0");
			

			if (locshowlesstooltips == 0) {
				$('#tx-tc-rts-disp2-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right', offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
				$('#tx-tc-rts-disp2-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
				$('#tx-tc-rts-dp-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right', offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
				$('#tx-tc-rts-dp-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
			} else {
				$('#tx-tc-rts-disp2-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
				$('#tx-tc-rts-disp2-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
				$('#tx-tc-rts-dp-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
				$('#tx-tc-rts-dp-' + tcidarr[1] + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
				
			}
		});

		// change gender in commenting form
		$(topid + '.tx-tc-defuserpic').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-toctoc-comments-comments-img-gender-','');
			if ((this.id).length !== tccid.length) {
				changedefuserpic(tccid.substr(0,1),tccid.substr(2));
			}
		});

		// closing coc
		$(topid + '.tx-tc-cocfuncs').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-cocfuncs-','');
			if ((this.id).length !== tccid.length) {
					toctoc_coc_close(tccid);
			}
		});

		// Comment crop link
		$(topid + '.tx-tc-tcsroc').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-tcsroc-','');
			if (tccid != this.id) {
				$(topid + '.tx-tc-tooltip').hide();
				tcsroc(tccid);
			}
		});

		// activate sharrre
		if (trgrebind != 'comment') {
			$(topid + '.tx-tc-sharre-trigger').on( "click", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-sharre-id-','');
				if ((this.id).length != tccid.length) {
					if (document.getElementById('tx-tc-sharre-id-' + tccid)) {
						var fname = 'tcrebshr' + tccid;
						var fn = window[fname];
						var fnExists = typeof fn === 'function';
						var isfunction = 'no';
						if (fnExists) {
							isfunction = 'ok';
						}
						if(isfunction == 'ok') {
							window.setTimeout("tcrebshr" + tccid + "()",5);
						}
					}
	
				}
	
			});	
		}


		// treeview expand icons
		$(topid + '.tx-tc-expandicon').on( "click", function() {
			// : tctrvw(expand, uid, children, allchildren)
			jtctrvw(this);
		});

		// treeview text links
		$(topid + '.tx-tc-nbrsubcomments').on( "click", function() {
			jtctrvw(this);
		});
		if (trgrebind != 'comment') {
			// Comment-link on top
			$(topid + '.tx-tc-openerform').on( "blur", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-openerform','');
				if ((this.id).length != tccid.length) {
					tcidarr = String(tccid).split("__0");
					if (tcidarr.length > 1) {
						comment_formhider(tcidarr[0], 1, '', tcidarr[1], 0, document.getElementById(tctnme + tcidarr[0]));
					}
				}
			});
		}
		//targeted emojitiptexts
		$(topid + '.tx-tc-tipemo-1').on( "mouseenter", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-tipemo-1-','');
			if ((this.id).length != tccid.length) {
				tcidarr = String(tccid).split("__0");
				if (tcidarr.length > 1) {
					tccid=tcidarr[1];
					if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
						$('#' + tcidarr[0] + tccid + ' .emoji[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
						$('#' + tcidarr[0] + tccid + ' img[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
						$('#tx-tc-ct-box-cttxt-' + tccid + ' img[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
						//console.log ('#tx-tc-ct-box-cttxt-' + tccid + ' img[title]');
					} else {
						$('#' + tcidarr[0] + tccid + ' .emoji').removeAttr('title');
						$('#' + tcidarr[0] + tccid + ' img').removeAttr('title');
					}
					if (locshowlesstooltips == 0) {
						$('#tx-tc-rts-disp2-tx_toctoc_comments_comments_' + tccid + ' .tx-tc-rts-dp .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
						$('#tx-tc-rts-disp2-tx_toctoc_comments_comments_' + tccid + ' .tx-tc-rts-dp .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
						$('#tx-tc-myrts-dp-tx_toctoc_comments_comments_' + tccid + ' div div a img[title]').cooltip({effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip'});
						$('#tx-tc-myrts-dp-tx_toctoc_comments_comments_' + tccid + ' div div img[title]').cooltip({effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip'});
						$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
						$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
					} else {	
						$('#tx-tc-rts-disp2-tx_toctoc_comments_comments_' + tccid + ' .tx-tc-rts-dp .tx-tc-rts-vote-bar div span').removeAttr('title');
						$('#tx-tc-rts-disp2-tx_toctoc_comments_comments_' + tccid + ' .tx-tc-rts-dp .tx-tc-rts-vote-bar div a').removeAttr('title');
						$('#tx-tc-myrts-dp-tx_toctoc_comments_comments_' + tccid + ' div div a img').removeAttr('title');
						$('#tx-tc-myrts-dp-tx_toctoc_comments_comments_' + tccid + ' div div img').removeAttr('title');
						$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
						$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
					}
				}
			}
		});
		$(topid + '.tx-tcresponse-text').on( "mouseenter", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-id-tcresponse-text-','');
			if ((this.id).length != tccid.length) {
				if ((locshowlesstooltips == 0) && (emojinotooltips == 0)) {
					$('#tx-id-tcresponse-text-' + tccid + ' .emoji[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
					$('#tx-id-tcresponse-text-' + tccid + ' img[title]').cooltip({offset: [-1,0],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltipemoji'});
				} else {
					$('#tx-id-tcresponse-text-' + tccid + ' .emoji').removeAttr('title');
					$('#tx-id-tcresponse-text-' + tccid + ' img').removeAttr('title');
					
				}
			}
		});

		$(topid + '.tx-tc-tipemo-2').on( "mouseenter", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-tipemo-2-','');
			if ((this.id).length !== tccid.length) {
				if (locshowlesstooltips == 0) {
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
				} else {					
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
				}
			}
		});
		if (trgrebind != 'comment') {
			$(topid + '.tx-tc-overrating-voting').on( "mouseenter", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-rts-disp2-','');
				if (locshowlesstooltips == 0) {
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade', opacity: 1, tipClass: 'tx-tc-tooltip2'});
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a[title]').cooltip({position: 'top right',offset: [5,-5],effect: 'fade',opacity: 1, tipClass: 'tx-tc-tooltip2'});
				} else {
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
					$('#tx-tc-rts-disp2-' + tccid + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div span').removeAttr('title');
					$('#tx-tc-rts-dp-' + tccid + ' .tx-tc-rts-vote-bar div a').removeAttr('title');
					
				}
					
			});
				
		}
		// comment edit
		rebindediticon(topid);

		//comment browsing
		if ((trgrebind == 'browse') || (trgrebind == '')) {
			$(topid + '.tx-tc-cts-ctsbrowse-submit-hide').on( "click", function() {
				tccid = this.id;
				tccid = tccid.replace('toctoc_comments_pi1_submit_bhcid','');
				tttip('hide');
				txtcbrowsesubmitclick(this,tccid);
				tttip('t101','.tx-tc-cts-ctsbrowse-submit[title]');
			});
	
			$(topid + '.tx-tc-cts-ctsbrowse-submit').on( "click", function() {
				tccid = this.id;
				tccid = tccid.replace('toctoc_comments_pi1_submit_bcid','');
				tttip('hide');
				txtcbrowsesubmitclick(this,tccid);
				tttip('t101','.tx-tc-cts-ctsbrowse-submit[title]');
				tttip('t101','.tx-tc-cts-ctsbrowse-submit-hide[title]');
			});
		}

		// comments denotify icon
		$(topid + '.tx-tc-ct-denotifybutton').on( "click", function() {
	 		tccid = this.id;
			tccid = tccid.replace('toctoc_comments_pi1_submit_uid','');
			if ((this.id).length !== tccid.length) {
				tcidarr = String(tccid).split("__0");
				tccid=tcidarr[2];
				tcidarr2 = String(tccid).split("6g9");
				if (tcidarr2.length === 3) {
					tccid2=tcidarr2[0];
				} else {
					tccid2=tccid;
				}
				tttip('hide');
				tcnum = toctoc_comments_denotify(tcidarr[0],tcidarr[1], commentsAjaxData[tccid2], tcidarr[3],  tcidarr[4],  tcidarr[5], commentsAjaxDataC[tccid2], commentsAjaxThisData[tccid2], tcidarr[6], tccid);
			}
		});

		$(topid + '.tx-tc-ct-denotifybutton').on( "mouseout", function() {
		 	$(topid + '.tx-tc-tooltip').hide();
		});

		// uploadpic event
		$(topid + '.tx-tc-uplpic-trigger').on( "click", function() {
		// tx-tc-uplpic-trigger-###CID###__0###LANG###__0###PVSHEIGHT###
			tccid = this.id;
			tccid = tccid.replace('tx-tc-uplpic-trigger-','');
			if ((this.id).length !== tccid.length) {

				$('input#toctoc_comments_pi1_'+tccid+'uploadpic').on( "change", function() {
					tccid = this.id;
					tccid = tccid.replace('toctoc_comments_pi1_','');
					tccid = tccid.replace('uploadpic','');
					tcidarr2 = String(tccid).split("6g9");
					if (tcidarr2.length === 3) {
						tccid2=tcidarr2[0];
					} else {
						tccid2=tccid;
					}

					tcfilechange_delayed(tccid, commentsAjaxData[tccid2], commentsAjaxDataAtt[tccid2]);
				});
				$('img#tx-tc-cts-nopreviewfup-'+tccid).on( "click", function() {
					tccid = this.id;
					tccid = tccid.replace('tx-tc-cts-nopreviewfup-','');
					tcidarr2 = String(tccid).split("6g9");
					if (tcidarr2.length === 3) {
						tccid2=tcidarr2[0];
					} else {
						tccid2=tccid;
					}
					remove_fup_pic(tccid, previewstartedfp[tccid2], previewfpheight[tccid2], commentsAjaxData[tccid2], commentsAjaxDataAtt[tccid2]);
				});
			}
		});

		// comments delete button
		$(topid + '.tx-tc-ct-deletebutton').on( "click", function() {
	 		tccid = this.id;
			tccid = tccid.replace('toctoc_comments_pi1_submit_uid','');
			if ((this.id).length !== tccid.length) {
				tcidarr = String(tccid).split("__0");
				tccid=tcidarr[2];
				tttip('hide');
				tcnum = toctoc_comments_delete(tcidarr[0],tcidarr[1], commentsAjaxData[tccid], tcidarr[3],  tcidarr[4],  tcidarr[5], commentsAjaxDataC[tccid], commentsAjaxThisData[tccid], tcidarr[6], tccid,  tcidarr[7], commentsAjaxDataImg[tccid],tcidarr[8],tcidarr[9]);
			}

		});
		$(topid + '.tx-tc-ct-deletebutton').on( "mouseout", function() {
		 	$('.tx-tc-tooltip').hide();
		});

		// comments submit button
		$(topid + '.tx-tc-ct-submit').on( "click", function() {
			tccid = this.parentNode.parentNode.id;
			tccid = tccid.replace('cffs','');
			if ((this.parentNode.parentNode.id).length !== tccid.length) {

				txtcctsubmitclick(this);
			} else {
				//when captcha
				tccid = this.parentNode.parentNode.parentNode.id;
				if (tccid.substr(0,4) != 'cffs') {
					txtcctsubmitclick(this);
				} else {
					txtcctsubmitclick(this.parentNode);
				}
				
			}
			
		});
		$(topid + '.tx-tc-ct-submit-loggedin').on( "click", function() {
			tccid = this.parentNode.parentNode.parentNode.id;
			if (tccid.substr(0,4) != 'cffs') {
				txtcctsubmitclick(this);
			} else {
				txtcctsubmitclick(this.parentNode);
			}			
			
		});
		
		// submit of password change
		if (document.getElementById('tx_toctoccomments_pi2_cp')) {
			tccid = document.getElementById('tx_toctoccomments_pi2_cp').innerHTML;

			if (tccid != '') {
				tccid2 = tccid.replace('ERROR','');
				document.getElementById('tx_toctoccomments_pi2_cp').innerHTML=tccid2;
				$('#tx-tc-loginformcp').removeClass("tx-tc-nodisp");
				$('#tx-tc-loginformcp').addClass("tx-tc-blockdisp");
				if (tccid2 != tccid) {
					window.setTimeout("rebindcpback(1)", 5500);
				} else {
					$('#tx_toctoccomments_pi2_submitcp').on("click", function() {
						
						ttc_ajaxfecp(this);
					});

				}
			}
		}
		
		if (document.getElementById('tx-tc-cpwf')) {
			tccid = utf8_decode(tcb64_dec(tcpasswordcard));
			if (tccid != '') {
				tccid2 = tccid.replace('ERROR','');
				document.getElementById('tx-tc-cpwf').innerHTML = 	tccid2;
				$('#tx-tc-cpwf').removeClass("tx-tc-nodisp");
				$('#tx-tc-cpwf').addClass("tx-tc-blockdisp");
				$('#tx-tc-loginformcp').removeClass("tx-tc-nodisp");
				$('#tx-tc-loginformcp').addClass("tx-tc-blockdisp");
				if (tccid2 != tccid) {
					window.setTimeout("rebindcpback(1)", 5500);
				} else {
					document.getElementById('tx_toctoc_comments_pi2-changepassword1').focus();
					$('#tx_toctoccomments_pi2_submitcp').on("click", function() {
						
						ttc_ajaxfecp(this);
					});
					document.getElementById('tx_toctoc_comments_pi2-changepassword1').value = '';
				}

			}

		}
		// comments sortarray will be loaded in dom from html
		$(topid + '.tx-tc-sortinfo').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-sortinfos_','');
			tcidarr = String(tccid).split("__0");
			// ###CID###__0###COMMENT_ID###__0###SORTING###__0###SORTPOPULAR###__0###SQNUMBER###__0###POPNUMBER###__0seqnumber__0level
			var elem = sortArr[tcidarr[1]];
			if (elem) {
				//console.log ('tcidarr[1] found ' + tcidarr[1] + ': ' + sortArr[1]);	
			} else {
				sortArr[tcidarr[1]] = [];
				if (tcidarr[1]) {
					sortArr[tcidarr[1]][0] = tcidarr[1];
					sortArr[tcidarr[1]][1] = tcidarr[2];
					sortArr[tcidarr[1]][2] = tcidarr[3];
					sortArr[tcidarr[1]][3] = tcidarr[4];
					sortArr[tcidarr[1]][4] = tcidarr[5];
					sortArr[tcidarr[1]][5] = tcidarr[6];
					sortArr[tcidarr[1]][6] = tcidarr[7];
					sortArr[tcidarr[1]][7] = this.parentNode.id;
					sortArr[tcidarr[1]][8] = tcidarr[0];
				}
				
			}
		});
		$(topid + '.tx-tc-sortlistlink').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-sortlistlink_','');
			tcidarr = String(tccid).split("__0");
			// ###CID###__0###ID###__0###ACTIONSORT###
			if (tcidarr[2]) {
				// triggering function toctoc_comments_sort(id, action, cid)
				$('#tx-tc-sortlistmenutitle_' + tcidarr[0] + '__0' + tcidarr[1]).removeClass('tx-tc-menutitle-hilight');
				toctoc_comments_sort( tcidarr[1],  tcidarr[2],  tcidarr[0]);
				update_sort_menu(tccid);
			}
		});
		
		$(topid + '.tx-tc-terms-check').on( "click", function() {
			tccid = this.id;
			//toctoc_comments_pi1_' . $cid . 'acceptterms
			var field = document.getElementById(tccid);
			var value = 0;
			if (field) {
				if (field.checked === true) {
					value = 1;
				}
			}
			toctoc_comments_pi1_createCookie('toctoc_comments_pi1_tc', value, cookieLifetime);
			 
		});
		
		$(topid + '.tx-tc-cookie-checker').on( "click", function() {
			tccid = this.id;
			var field = document.getElementById(tccid);
			var value = 0;
			if (field) {
				if (field.checked === true) {
					value = 1;
				}
			}
			toctoc_comments_pi1_createCookie('toctoc_comments_pi1_dataProtect', value, cookieLifetime);			 
		});
		
		$(topid + '.tx-tc-sortlistmenutitle').on( "click", function() {
			tccid = this.parentNode.id;
			tccid = tccid.replace('tx-tc-sortlistmenu_','tx-tc-sortlistpanel_');
			if (!($('#' + tccid).hasClass('tx-tc-blockdisp'))) {
				$('#' + tccid).removeClass('tx-tc-nodisp');
				$('#' + tccid).addClass('tx-tc-blockdisp');
				$('#' + this.id).addClass('tx-tc-menutitle-hilight');
			} else {
				$('#' + tccid).removeClass('tx-tc-blockdisp');
				$('#' + tccid).addClass('tx-tc-nodisp');
				$('#' + this.id).removeClass('tx-tc-menutitle-hilight');
			}
			tccid = this.parentNode.id;
			tccid = tccid.replace('tx-tc-sortlistmenu_','tx-tc-dsclmrlistpanel_');
			if (($('#' + tccid).hasClass('tx-tc-blockdisp'))) {
				$('#' + tccid).removeClass('tx-tc-blockdisp');
				$('#' + tccid).addClass('tx-tc-nodisp');
				tccid = this.id.replace('tx-tc-sortlistmenutitle','tx-tc-dsclmrlistmenutitle');
				$('#' + tccid).removeClass('tx-tc-menutitle-hilight');
			}
			 
		});
		function dsc_points (tccid, points) {
			var ptsprcnt = Math.round(parseFloat(100*(points/4)));
			$('#tx-tc-dsclmrcheckresult_count_' + tccid).html(points);
			if (points < 1.5) {
				$('#tx-tc-dsclmrcheckresult_' + tccid).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportminimal)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid).addClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-info');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-green');
			} else if ((points >= 1.5) && (points <= 3)) {
				$('#tx-tc-dsclmrcheckresult_' + tccid).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportcouldbebetter)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid).addClass('tx-tc-info');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-green');				
			} else if (points > 3) {
				$('#tx-tc-dsclmrcheckresult_' + tccid).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportlooksgood)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid).addClass('tx-tc-green');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid).removeClass('tx-tc-info');
			}
		}
		
		$(topid + '.tx-tc-dsclmrlistmenutitle').on( "click", function() {
			tccid = this.parentNode.id;
			tccid = tccid.replace('tx-tc-sortlistmenu_','tx-tc-dsclmrlistpanel_');
			if (!($('#' + tccid).hasClass('tx-tc-blockdisp'))) {
				$('#' + tccid).removeClass('tx-tc-nodisp');
				$('#' + tccid).addClass('tx-tc-blockdisp');
				$('#' + this.id).addClass('tx-tc-menutitle-hilight');
				// check https
				tccid2 = tccid.replace('tx-tc-dsclmrlistpanel_','');
				var points = parseFloat($('#tx-tc-dsclmrcheckresult_count_' + tccid2).html());
		
				if (location.protocol == 'https:') {
					if (($('#tx-tc-dsclmrhttps_' + tccid2).hasClass('tx-tc-warn'))) {
						$('#tx-tc-dsclmrhttps_' + tccid2).html(utf8_decode(tcb64_dec(textdisclaimerhttps)));
						$('#tx-tc-dsclmrhttps_' + tccid2).removeClass('tx-tc-warn');
						$('#tx-tc-dsclmrhttps_' + tccid2).addClass('tx-tc-green');
						points = parseFloat(points+1);
					}
					
				}
				
				if (location.protocol == 'http:') {
					if (($('#tx-tc-dsclmrhttps_' + tccid2).hasClass('tx-tc-green'))) {
						$('#tx-tc-dsclmrhttps_' + tccid2).html(utf8_decode(tcb64_dec(textdisclaimernohttps)));
						$('#tx-tc-dsclmrhttps_' + tccid2).removeClass('tx-tc-green');
						$('#tx-tc-dsclmrhttps_' + tccid2).addClass('tx-tc-warn');
						points = parseFloat(points-1);
					}
					
				}
				
				if (parseFloat($('#tx-tc-dsclmrcheckresult_count_' + tccid2).html()) != points) {
					dsc_points (tccid2, points);
				}
				
			} else {
				$('#' + tccid).removeClass('tx-tc-blockdisp');
				$('#' + tccid).addClass('tx-tc-nodisp');
				$('#' + this.id).removeClass('tx-tc-menutitle-hilight');
			}
			
			tccid = this.parentNode.id;
			tccid = tccid.replace('tx-tc-sortlistmenu_','tx-tc-sortlistpanel_');
			if (($('#' + tccid).hasClass('tx-tc-blockdisp'))) {
				$('#' + tccid).removeClass('tx-tc-blockdisp');
				$('#' + tccid).addClass('tx-tc-nodisp');
				tccid = this.id.replace('tx-tc-dsclmrlistmenutitle', 'tx-tc-sortlistmenutitle');
				$('#' + tccid).removeClass('tx-tc-menutitle-hilight');
			}
			 
		});
		
		$('.tx-tc-cookieclose').on( "click", function() {
			tccid2 = this.id;
			tccid = tccid2.replace('tx-tc-cookie-cls-','');
			tccid2 = tccid2.replace('tx-tc-cookie-cls-','tx_tc_cookie_');
			tccidarr = tccid.split('_');
			tttip('hide');
			toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_' + tccidarr[0]);
			
			$('#' + tccid2).removeClass('tx-tc-dsclmrcheck');
			$('#' + tccid2).addClass('tx-tc-nodisp');
			var cookiecount = '';
			var addpoints = 0;
			tccid = tccid.substring(parseInt(1+String(tccid).indexOf("_")));
			var points = parseFloat($('#tx-tc-dsclmrcheckresult_count_' + tccid).html());
			var cookiecount = $('#tx-tc-cookie-count_' + tccid).html();
			tccidarr = cookiecount.split('_');
			addpoints =  parseFloat(1/parseInt(tccidarr[1]));
			$('#tx-tc-cookie-count_' + tccid).html(parseInt(parseInt(tccidarr[0])-1) + '_' + tccidarr[1]);
			
			if (parseInt(parseInt(tccidarr[0])-1) == 0) {
				$('#tx-tc-cookie-dropup_' + tccid).removeClass('tx-tc-dsclmrcheck');
				$('#tx-tc-cookie-dropup_' + tccid).addClass('tx-tc-nodisp');				
			}
			
			points = parseFloat(addpoints) + parseFloat(points);
			
			dsc_points (tccid, points);
			
		});
		
		$('.tx-tc-cookieshow').on( "click", function() {
			tccid = this.id;
			tccid2 = tccid.replace('tx-tc-cookie-cls-dropup_','tx-tc-cookie-dropuppanel_');
			tttip('hide');
			$('#' + tccid2).addClass('tx-tc-blockdisp');
			$('#' + tccid2).removeClass('tx-tc-nodisp');
			$('#' + tccid).addClass('tx-tc-nodisp');
			$('#' + tccid).removeClass('tx-tc-blockdisp');
		});
		
		$('.tx-tc-cookieaccept').on( "click", function() {
			tccid = this.id;
			tccid2 = tccid.replace('tx-tc-cookie-accept_','');
			var accepting = 1;
			if (tccid == tccid2) {
				accepting = 0;
				tccid2 = tccid.replace('tx-tc-cookie-notaccept_','');
			}
			var cookiecount = 0;
			var addpoints = -1;
			var points = parseFloat($('#tx-tc-dsclmrcheckresult_count_' + tccid2).html());
			
			toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_dataProtect');
			if (accepting == 1) {
				toctoc_comments_pi1_createCookie('toctoc_comments_pi1_dataProtect', 1, cookieLifetime);
				$('#tx-tc-cookie-accept_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx-tc-cookie-accept_' + tccid2).removeClass('tx-tc-blockdisp');
				$('#tx-tc-cookie-notaccept_' + tccid2).addClass('tx-tc-blockdisp');
				$('#tx-tc-cookie-notaccept_' + tccid2).removeClass('tx-tc-nodisp');
				$('#tx-tc-cookie-msg_' + tccid2).html($('#tx-tc-cookie-accept_msg1_' + tccid2).html()); 
				$('#tx-tc-cookie-msg_' + tccid2).addClass('tx-tc-warn');
				$('#tx-tc-cookie-msg_' + tccid2).removeClass('tx-tc-green');
				$('#tx-tc-cookie-msg_' + tccid2).removeClass('tx-tc-info');

			} else {
				toctoc_comments_pi1_createCookie('toctoc_comments_pi1_dataProtect', 0, cookieLifetime);
				$('#tx-tc-cookie-notaccept_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx-tc-cookie-notaccept_' + tccid2).removeClass('tx-tc-blockdisp');
				$('#tx-tc-cookie-accept_' + tccid2).addClass('tx-tc-blockdisp');
				$('#tx-tc-cookie-accept_' + tccid2).removeClass('tx-tc-nodisp');
				$('#tx-tc-cookie-msg_' + tccid2).html($('#tx-tc-cookie-accept_msg0_' + tccid2).html()); 
				$('#tx-tc-cookie-msg_' + tccid2).addClass('tx-tc-green');
				$('#tx-tc-cookie-msg_' + tccid2).removeClass('tx-tc-warn');
				$('#tx-tc-cookie-msg_' + tccid2).removeClass('tx-tc-info');
				//erasing possible cookies that could be present
				
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_firstname');
				$('#tx_tc_cookie_firstname_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_firstname_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_lastname');
				$('#tx_tc_cookie_lastname_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_lastname_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_email');
				$('#tx_tc_cookie_email_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_email_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_gender');
				$('#tx_tc_cookie_gender_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_gender_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_location');
				$('#tx_tc_cookie_location_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_location_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				toctoc_comments_pi1_eraseCookie('toctoc_comments_pi1_homepage');
				$('#tx_tc_cookie_homepage_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx_tc_cookie_homepage_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				
				$('#tx-tc-cookie-dropup_' + tccid2).addClass('tx-tc-nodisp');
				$('#tx-tc-cookie-dropup_' + tccid2).removeClass('tx-tc-dsclmrcheck');
				
				cookiecount = $('#tx-tc-cookie-count_' + tccid2).html();
				tccidarr = cookiecount.split('_');
				addpoints =  parseFloat(1 + parseFloat(parseInt(tccidarr[0])/parseInt(tccidarr[1])));
				cookiecount = 0;
				
			}
			points = parseFloat(addpoints) + parseFloat(points);
			var ptsprcnt = Math.round(parseFloat(100*(points/4)));
			$('#tx-tc-dsclmrcheckresult_count_' + tccid2).html(points);
			if (points < 1.5) {
				$('#tx-tc-dsclmrcheckresult_' + tccid2).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportminimal)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).addClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-info');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-green');
			} else if ((points >= 1.5) && (points <= 3)) {
				$('#tx-tc-dsclmrcheckresult_' + tccid2).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportcouldbebetter)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).addClass('tx-tc-info');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-green');				
			} else if (points > 3) {
				$('#tx-tc-dsclmrcheckresult_' + tccid2).html(utf8_decode(tcb64_dec(textdisclaimersafetyreportlooksgood)) + ' (' + ptsprcnt + '%)');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).addClass('tx-tc-green');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-warn');
				$('#tx-tc-dsclmrcheckresult_' + tccid2).removeClass('tx-tc-info');
			}
			
			cookiecount = $('#tx-tc-cookie-count_' + tccid2).html();
			tccidarr = cookiecount.split('_');
			$('#tx-tc-cookie-count_' + tccid2).html('0_' + parseInt(tccidarr[1]));
			tttip('hide');
		});
		
		// comments_view counters
		$(topid + '.tx-tc-cmtvcntr').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cmtvcntr__','');
			tcidarr = String(tccid).split("__");
			if (tcidarr[2].length < 20) {
				tcidarr2 = String(tcidarr[2]).split("6g9");
				if (tcidarr2.length === 3) {
					tccid2=tcidarr2[0];
				} else {
					tccid2=tcidarr[2];
				}
				tcidarr[2]=commentsAjaxData[tccid2];
			}
			tcnum = comments_view(tcidarr[0],tcidarr[1],tcidarr[2],tcidarr[3],tcidarr[4]);
		});
		if (trgrebind != 'comment') {
			$(topid + '.tx-tc-initpreviewvrs').on( "click", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-initpreviewvrs-','');
				if ((this.id).length !== tccid.length) {
					if (!previewstarted[tccid]) {
					    previewstarted[tccid] = 0;
					    previewstartedfp[tccid] = 0;
					    previewfpheight[tccid] = 0;
					    previewselpic[tccid] = 888;
					    previewselpreviewid[tccid] = 0;
					    previewcountnr[tccid] = 0;
					    previewfpcountnr[tccid] = 0;
					    previewhtml[tccid] = '';
					    previewselcomment[tccid] = 0;
					    previewstartedfup[tccid] = 0;
					}
				}
	
			});
			$(topid + '.tx-tc-setuserdata').on( "click", function() {
				toctoc_comments_pi1_setUserDatawrap(this);
			 });
		}
		
		$(topid + '.tx-tc-othertitle').on( "click", function() {
			othertooltip(this);
		});
		$(topid + '.tx-tc-uploadlink').on( "click", function() {
			uploadclick(this);
		});

		$(topid + '.tx-tc-wtrmrk-formf').on( "click", function() {
			wtrmrk(this);
		});
		$(topid + '.tx-tc-wtrmrk-tcnt').on( "click", function() {
			wtrmrk(this);
		});

		// logout function in login required mode
		$(topid + '.tx-tc-loggout-data').on( "mouseenter", function() {
			overlogout=1;
		});
		$(topid + '.tx-tc-loggout-data').on( "mouseout", function() {
			overlogout=0;
		});
		$(topid + '.tx-tc-loggout-data').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-loggout-data-','');
			tcidarr = String(tccid).split("__0");
			tt_logout(tcidarr[0],tcidarr[1]);
		});

		// closing the web page previews and preview pictures
		$(topid + '.tx-tc-pvs-pvsnopreview').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-pvsnopreview-','');
			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid=tcidarr[0];
			}

			toctoc_previewurl_close(tccid2, previewstarted[tccid2], confpvsheight, commentsAjaxData[tccid],  commentsAjaxDataAtt[tccid]);
		 });

		//uc link
		$(topid + '.tx-tc-picclasslink').on("click", function() {
			ucclick(this);
		});
		$(topid + '.tx-tc-commenttextuclink').on("click", function() {
			ucclick(this);
		});

		$(topid + '.tx-tc-working').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-form-wpp-working','');
			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid=tcidarr[0];
			}
			toctoc_previewurl_close(tccid2, previewstarted[tccid2], confpvsheight, commentsAjaxData[tccid],  commentsAjaxDataAtt[tccid]);
		});
		$(topid + '.tx-tc-ctinput-textarea').on('keyup click', function(e) {
		    	tccid = this.id;

				tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
				if ((this.id).length !== tccid.length) {
					tccid2 =tccid;
					tcidarr = String(tccid).split("6g9");

					if (tcidarr.length === 3) {
						tccid=tcidarr[0];
					} else {
						tccid=tccid2;
					}
					if (tccid2 == 1) {
						activelang = 'jedi';
					}
					tcnum = toctoc_checkurl(e.keyCode,document.getElementById(tctnme + tccid2),tccid2, previewstarted[tccid2], activelang, confpvsheight, commentsAjaxData[tccid],  commentsAjaxDataAtt[tccid], maxCommentLength, e.pageX, e.pageY, e.which);
			        previewstarted[tccid2] = tcnum;
				}
		});

		$(topid + '.tx-tc-ctinput-textarea').on('blur', function() {
			tccid = this.id;
			caseupl=0;
			tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
			if ((this.id).length === tccid.length) {
				tccid = tccid.replace('toctoc_comments_pi1_uplcontenttextbox_','');
				caseupl=1;
			}

			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid=tcidarr[0];
			}

			if (caseupl==1) {
				caseupl=0;
		    	if (tctrim(this.value)=='') {
		    		$('#toctoc_comments_pi1_uplcontenttextbox_'+tccid2).elastic();
		    	} else {
		    		if (tctrim(this.value)!='') {
		    			$('#toctoc_comments_pi1_uplcontenttextbox_'+tccid2).elastic();
		    		}

		    	}

			} else {
				tcidarr2 = String(tccid).split("__0");
				if (tcidarr2.length==2) {
					tccid = tcidarr2[0];
				}
				if (parseInt(tccid) == 1) {
					if ((tctrim(this.value)=='') && (tctrim( utf8_decode(tcb64_dec(tcidarr2[1])))=='')) {
						comment_formhider('1', 2, utf8_decode(tcb64_dec(textAddComplaint)), 0,1);
						window.setTimeout("document.getElementById('" + this.id + "').style.height= '';jQuery('#toctoc_comments_pi1_contenttextbox_1').elastic();",50);
					} else {
						if (tctrim(this.value)!='') {
							window.setTimeout("document.getElementById('" + this.id + "').style.height= '';jQuery('#toctoc_comments_pi1_contenttextbox_1').elastic();",50);
						}
					}
				} else {
					if (tctrim(this.value)=='') {
						comment_formhider(tccid2, 2, utf8_decode(tcb64_dec(textAddComment)), global_loggedon,1);
						window.setTimeout("document.getElementById('" + this.id + "').style.height= '';jQuery('#"+this.id+"').elastic();",50);
					} else {
						if (tctrim(this.value)!='') {
							window.setTimeout("jQuery('#"+this.id+"').elastic();",50);
						}

					}
				}

			}
		});

		$(topid + '.tx-tc-ctinput-textarea').on('focus', function() {
			$('#'+this.id +'').elastic();
			tccid = this.id;
			tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
			caseupl=0;
			if ((this.id).length === tccid.length) {
				tccid = tccid.replace('toctoc_comments_pi1_uplcontenttextbox_','');
				caseupl=1;
			}
			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");
			if (caseupl==1) {
		    	$('#toctoc_comments_pi1_uplcontenttextbox_'+tccid2).elastic();
		    	caseupl=0;
			} else {
				tcidarr2 = String(tccid2).split("__0");
				if (tcidarr2.length==2) {
					tccid2 = tcidarr2[0];
				}
				if (tccid2 == '1') {
					$('#toctoc_comments_pi1_contenttextbox_1').elastic();
					if (document.getElementById('toctoc_comments_pi1_submit_1').style.display !== 'block') {
						this.value='';
						comment_formhider('1', 3, '', 0 ,1);
					}

				} else {
					if (tcidarr.length === 3) {
						tccid=tcidarr[0];
						window['previewselcomment'+tccid2] = tccid;
					}

					if (document.getElementById(tcsbmtnme+tccid2).style.display !== 'block') {
						this.value='';
						comment_formhider(tccid2, 3, '', global_loggedon,1);
					}
				}
			}
		});

		$(topid + '.tx-tc-ctinput-textarea-rq').on('blur', function() {
			tccid = this.id;
			tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");

			if (tcidarr.length === 3) {
				tccid=tcidarr[0];
			}
			if (tctrim(this.value)!='') {
				$('#'+this.id +'').elastic();
			} else {
				currentcommenttext[this.id] = '';
			};

		});

		$(topid + '.tx-tc-ctinput-textarea').on("paste", function(e) {
   		if (this.value=='') {
    			window.setTimeout("checkpaste('"+this.id+"', '"+e.keyCode+"', '"+e.pageX+"', '"+e.pageY+"', '"+e.which+"');",100);
     		}

		});
		$(topid + '.tx-tc-ctinput-textarea-rq').on('change', function() {
			currentcommenttext[this.id] = this.value;
		});
		$(topid + '.tx-tc-ctinput-textarea').on('change', function() {
			if (global_loggedon==1) {
				currentcommenttext[this.id] = this.value;
			}
		});

		$(topid + '.tx-tc-form-for-newcomment').on('submit', function() {
			tccid = this.id;
			tccid = tccid.replace('cf','');
			$('#toctoc_comments_pi1_submit_'+tccid).trigger("click");
			return false;
		});

		$(topid + '.tx-tc-ctinput-textarea-rq').on('focus', function() {
			$('#'+this.id +'').elastic();
			tccid = this.id;
			tccid = tccid.replace('toctoc_comments_pi1_contenttextbox_','');
			tccid2 =tccid;
			tcidarr = String(tccid).split("6g9");
			if (tcidarr.length === 3) {
				tccid=tcidarr[0];
				window['previewselcomment'+tccid2] = tccid;
			}

			tccid3 = document.getElementById("formhider-"+tccid2).innerHTML;
			if ((String(tccid3)=='') || (String(tccid3).indexOf("loginfor") > 0)) {
				comment_formhider(tccid2, 3, '', 0,1);
				tt_showlogin(tccid2,1);
				lastshownloginformid = tccid2;
			} else {
				lastshownloginformid = '';
				comment_formhider(tccid2, 3, '', 0,1);
				lastshownloginformid = tccid2;
			};
		});
		// liking
		function likeclicks(itopid) {
			$(itopid + 'a.tx-tc-rts-star-l').on("click", function() {
				likeclick(this);
			 });
		}
		likeclicks(topid);


		function starclicks(itopid) {
			$(itopid + 'a.tx-tc-rts-star-v').on("click", function() {
				starclick(this);
			 });
		}
		starclicks(topid);

		// closing the web page previews and preview pictures

        $(topid + '.tx-tc-pvs-nopreviewpic').on( "click", function() {
        	tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-nopreviewpic-','');
			tcnum = remove_pvs_pic(tccid);
			previewselpic[tccid] = tcnum;
        });

        //change captcha picture
        $(topid + '.tx-tc-cap-image-rf').on( "click", function() {
        		tccid = this.id;
    			tccid = tccid.replace('toctoc_comments_caprefresh_','');
    			tccid2 = tccid.replace('_ctp1', '');
    			if (tccid2.length !== tccid.length) {
     				tccid=tccid2;
      				tcidarr = String(tccid).split("__0");
					if (tcidarr.length > 1) {
						tccid2=tcidarr[1];
						tccid=tcidarr[0];
					}

    				change_captcha(tccid,1,tccid2);
    			} else {
    				tccid2 = tccid.replace('_ctp2', '');
        			if (tccid2.length !== tccid.length) {
        				tccid=tccid2;
        				tccid2='';
        				change_captcha(tccid,2,tccid2);
        			}

    			}

        });
        if (trgrebind != 'comment') {
	        // tooltips on topilikes
			$(topid + '.tx-tc-rts-area').on( "mouseenter", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-myrtstop-','');
				if ((this.id).length !== tccid.length) {
					tttip('t101','#tx-tc-myrtstop-dp-' + tccid + ' .tx-tc-atrtstop-ilike-dp a[title]');
				} else {
					tccid = tccid.replace('tx-tc-myrts-dp-','');
					if ((this.id).length !== tccid.length) {
						tttip('t101', '#tx-tc-myrts-dp-' + tccid + ' .tx-tc-myrts-ilke img[title]');
						tttip('t101', '#tx-tc-myrts-dp-' + tccid + ' .tx-tc-myrts-disilke img[title]');
					} else {
						tccid = tccid.replace('tx-tc-myrts-','');
						if ((this.id).length !== tccid.length) {
							tttip('t101', '#tx-tc-myrts-dp-' + tccid + ' .tx-tc-myrts-ilke img[title]');
							tttip('t101', '#tx-tc-myrts-dp-' + tccid + ' .tx-tc-myrts-disilke img[title]');
						}
					}
				}
			});
        }

		// videos, close
		$(topid + '.tx-tc-vidclose').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('playerclose', '');
			tccid2 = tccid.replace('top-p', '');
			if (tccid2.length !== tccid.length) {
				// top webpage, tccid2 =: ###IDPLUS###
				tccid=tccid2;
				tccid2='top-';
			} else {
				tccid2='';
				tccid=tccid.substr(1);
			}

			tccid3 = tccid.replace('Y', '');
			if (tccid3.length !== tccid.length) {
				// html5 video, tccid3 =: ###HTML5FLAG###
				tccid=tccid3;
				tccid3='Y';
			} else {
				tccid3='';
			}

			if (tccid3=='Y') {
				var myVideo=document.getElementById('vidimg'+tccid2+'p'+tccid+'index2');
				if (myVideo) {
					if (!(myVideo.paused)) {
					  myVideo.pause();
					}

				}

				$('#tx-tc-cts-vid-img-'+tccid2+'p'+tccid).css('display', 'block');
				$('#tx-tc-cts-vid-box-'+tccid2+'p'+tccid).css('display', 'none');
				$('#tx-tc-ct-box-ctclose'+tccid2+'p'+tccid).css('display', 'none');
				$('#tx-tc-cts-vid-title-'+tccid2+'p'+tccid).css('float', 'none');
				$('#tx-tc-cts-vid-desc-'+tccid2+'p'+tccid).css('float', 'none');
			} else {
				tccid3 =tccid2;
				if (tccid2 ==='') {
					tccid3 ='nrml-';
				}
				savemove[tccid3][tccid] = document.getElementById('tx-tc-cts-vid-box-'+tccid2+'p'+tccid).innerHTML;
				document.getElementById('tx-tc-cts-vid-box-'+tccid2+'p'+tccid).innerHTML='';
				$('#tx-tc-cts-vid-img-'+tccid2+'p'+tccid).css('display', 'block');
				$('#tx-tc-cts-vid-box-'+tccid2+'p'+tccid).css('display', 'none');
				$('#tx-tc-ct-box-ctclose'+tccid2+'p'+tccid).css('display', 'none');
				$('#tx-tc-cts-vid-title-'+tccid2+'p'+tccid).css('float', 'none');
				$('#tx-tc-cts-vid-desc-'+tccid2+'p'+tccid).css('float', 'none');
			}

		});

		// videos, show
		$(topid + '.tx-tc-vidshw').on( "click", function() {
			tccid = this.id;
			tccid = tccid.replace('playerp', '');
			tccid = tccid.replace('player', '');
			tccid2 = tccid.replace('top-p', '');
			if (tccid2.length !== tccid.length) {
				// top webpage, tccid2 =: ###IDPLUS###
				tccid=tccid2;
				tccid2='top-';
				tccid3='top-';
			} else {
				tccid2='';
				tccid3='nrml-';
				tccid=tccid.substr(0);
			}

			if (savemove[tccid3][tccid]){
				document.getElementById('tx-tc-cts-vid-box-'+tccid2+'p'+tccid).innerHTML=savemove[tccid3][tccid];
			}
			$('#tx-tc-cts-vid-img-'+tccid2+'p'+tccid).css('display', 'none');
			$('#tx-tc-cts-vid-box-'+tccid2+'p'+tccid).css('display', 'block');
			$('#tx-tc-ct-box-ctclose'+tccid2+'p'+tccid).css('display', 'block');
			$('#tx-tc-cts-vid-title-'+tccid2+'p'+tccid).css('float', 'left');
			$('#tx-tc-cts-vid-desc-'+tccid2+'p'+tccid).css('float', 'left');
			$('#vidimgp'+tccid+'index2').removeClass('tx-tc-pvsmxhgt');
		});
		if (trgrebind != 'comment') {
			// messages above form, close
			$(topid + '.tx-tc-topmsgcls').on("click", function() {
				tccid = this.id;
				tccid = tccid.replace('tx-tc-topmsg-cls-','');
				toctoc_comments_ftm_close(tccid);
			});
		}

		// web page preview naviator
		$(topid + 'img.tx-tc-pvs-next').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-pvsnext-','');
			tcnum = change_pvs_pic(tccid, previewselpic[tccid], 1);
			previewselpic[tccid]=tcnum;
	    });
		$(topid + 'img.tx-tc-pvs-prev').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cts-pvsprev-','');
			tcnum = change_pvs_pic(tccid, previewselpic[tccid], 0);
			previewselpic[tccid]= tcnum;
	    });

		// loginform
		if (loginRequiredIdLoginForm != '') {
			// login submit
			$(topid + '.tx-tc-login-submitlo').on("click", function() {
				$('#tx_toctoccomments_pi2_formlo').trigger("submit");
					ttc_ajaxfelogin(this,1);
			});
		}

		// handler when comment posts have errors
		$(topid + '.tx-tc-frmerrhndl').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-frmerrhndl','');
			tcidarr = String(tccid).split("__0");
			if (tcidarr[1] != '1') {
			    var tcerrfrm = tcidarr[0];
			    if (tcerrfrm == '1') {
					if (document.getElementById(tcsbmtnme+tcidarr[1]).style.display !== 'block') {
					    $('#'+ tctnme + tcidarr[1]).elastic();
					    comment_formhider(tcidarr[1], 3, '', 0, 0);
					}

			    }

		    } else {
			    var strtext = utf8_decode(tcb64_dec(tcidarr[0]));
				var strtfvalue = document.getElementById(tctnme + '1');
				if (strtfvalue) {
					if (document.getElementById('toctoc_comments_pi1_submit_1').style.display !== 'block') {
						if (strtext !='') {
							strtfvalue.value = strtext;
						}

						comment_formhider('1', 3, '', 0, 0);
						if (strtext !='') {
							strtfvalue.value = strtext;
						}

					}

				}

			}

	    });

		// handler for cid list
		$(topid + '.tx-tc-updatecidlist').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-updatecidlist','');
			tcidarr = String(tccid).split("__0");
			if (tcidarr.length == 2) {
				updateCIDList(tcidarr[0],tcidarr[1]);
			}

	    });
		$(topid + '.tx-tc-commentsAjaxData').on("click", function() {
			tccid = this.id;
			tccid = tccid.replace('tx-tc-cAD-data-cont-','');
			if (document.getElementById('tx-tc-cAD-' + tccid)) {
				commentsAjaxData[tccid] = document.getElementById('tx-tc-cAD-' + tccid).innerHTML;
				commentsAjaxDataImg[tccid] = document.getElementById('tx-tc-cADImg-' + tccid).innerHTML;
				commentsAjaxThisData[tccid] = document.getElementById('tx-tc-cThisData-' + tccid).innerHTML;
				commentsAjaxDataC[tccid] = document.getElementById('tx-tc-cADC-' + tccid).innerHTML;
				commentsAjaxDataAtt[tccid] = document.getElementById('tx-tc-cADAtt-' + tccid).innerHTML;
				commentsAjaxDataLogin[tccid] = document.getElementById('tx-tc-cADLi-' + tccid).innerHTML;
				commentsAjaxDataLoginSess[tccid] = document.getElementById('tx-tc-cADLS-' + tccid).innerHTML;
				commentsAjaxDataLogout[tccid] = document.getElementById('tx-tc-cADLo-' + tccid).innerHTML;
			}
		});

		$(document).ready(function(){

			if (topid === '') {
				// init indexed vars for previewing stuff
				$('.tx-tc-initpreviewvrs').trigger("click");
				$('.tx-tc-updatecidlist').trigger("click");
				// overlay mask jquery.tools popups
				$("img[rel]").superpose({mask: {
			        color: '#5475C8',
			        loadSpeed: 200,
			        opacity: 0.2
			      }});
			}
			init_triggers_by_clicks(topid);
		});
		tcinit_tooltipps();
	})(jQuery);
}

if (pi2_fbappId != '') {
	if (!(document.getElementById('fb-root'))) {
		document.body.innerHTML += '<div id="fb-root"></div>';
	}

	fbAsyncInit = function() {
		FB.init({
			appId: pi2_fbappId, // App ID
			channelURL : 'typo3conf/ext/toctoc_comments/pi2/channel.html', // Channel File
			status     : true, // check login status
			cookie     : true, // enable cookies to allow the server to access the session
			oauth      : true, // enable OAuth 2.0
			xfbml      : true  // parse XFBML
		});

		FB.getLoginStatus(function(response) {
		}, true);
	};

	// Load the SDK Asynchronously
	(function(d){
		var js, id = 'facebook-jssdk';
		if (d.getElementById(id)) {
			return;
		}

		js = d.createElement('script');
		js.id = id;
		js.async = true;
		js.src = "//connect.facebook.net/en_US/all.js";
		d.getElementsByTagName('head')[0].appendChild(js);
	}(document));

	function fbLogin() {
		FB.login(function(response) {
			if (response.authResponse) {
				ttc_ajaxfelogin(document.getElementById('tx_toctoccomments_pi2_submit'), 0, 'fbLogin');
			}
		}, {scope: pi2_fbscope});

	}
}
window.setTimeout("tcrebind()",50);
window.setTimeout("tcrebindemo()",75);
window.setTimeout("tt_showloginbind()",105);