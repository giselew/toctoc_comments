$( document ).on( "mobileinit", function() {
	$.extend( $.mobile , {
		ajaxEnabled: false,
		pushStateEnabled: false,
		hoverDelay: 1
	});
});